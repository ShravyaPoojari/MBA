import streamlit as st
import hashlib
from sqlalchemy import create_engine, text, inspect
from urllib.parse import quote_plus
from datetime import datetime

# Database configuration
password = quote_plus("Sony@123")
DATABASE_URL = f"postgresql://postgres:{password}@localhost:5432/market_basket_analysis"
engine = create_engine(DATABASE_URL)

def init_session_state():
    """Initialize session state variables"""
    if 'authenticated' not in st.session_state:
        st.session_state.authenticated = False
    if 'username' not in st.session_state:
        st.session_state.username = None

# Initialize session state at module level
init_session_state()

def check_table_exists(table_name):
    """Check if a table exists"""
    try:
        with engine.connect() as conn:
            inspector = inspect(engine)
            return table_name in inspector.get_table_names()
    except Exception as e:
        st.error(f"Error checking table existence: {str(e)}")
        return False

def init_db():
    """Initialize the database with required tables if they don't exist"""
    try:
        with engine.connect() as conn:
            # Create users table if it doesn't exist
            if not check_table_exists('users'):
                conn.execute(text('''
                    CREATE TABLE users (
                        id SERIAL PRIMARY KEY,
                        username TEXT UNIQUE NOT NULL,
                        password TEXT NOT NULL,
                        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
                    )
                '''))
            
            # Create analysis_history table if it doesn't exist
            if not check_table_exists('analysis_history'):
                conn.execute(text('''
                    CREATE TABLE analysis_history (
                        id SERIAL PRIMARY KEY,
                        username TEXT NOT NULL,
                        filename TEXT NOT NULL,
                        timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                        transaction_count INTEGER,
                        item_count INTEGER,
                        min_support REAL,
                        min_confidence REAL,
                        min_lift REAL,
                        frequent_itemset_count INTEGER,
                        rule_count INTEGER,
                        FOREIGN KEY (username) REFERENCES users (username)
                    )
                '''))
            
            # Create saved_itemsets table if it doesn't exist
            if not check_table_exists('saved_itemsets'):
                conn.execute(text('''
                    CREATE TABLE saved_itemsets (
                        id SERIAL PRIMARY KEY,
                        analysis_id INTEGER,
                        itemset TEXT NOT NULL,
                        support REAL,
                        FOREIGN KEY (analysis_id) REFERENCES analysis_history (id)
                    )
                '''))
            
            # Create saved_rules table if it doesn't exist
            if not check_table_exists('saved_rules'):
                conn.execute(text('''
                    CREATE TABLE saved_rules (
                        id SERIAL PRIMARY KEY,
                        analysis_id INTEGER,
                        antecedents TEXT NOT NULL,
                        consequents TEXT NOT NULL,
                        support REAL,
                        confidence REAL,
                        lift REAL,
                        FOREIGN KEY (analysis_id) REFERENCES analysis_history (id)
                    )
                '''))
            
            conn.commit()
            return True
    except Exception as e:
        st.error(f"Database initialization error: {str(e)}")
        return False

def hash_password(password):
    """Hash the password using SHA-256"""
    return hashlib.sha256(password.encode()).hexdigest()

def verify_user(username, password):
    """Verify if the username and password match"""
    try:
        with engine.connect() as conn:
            hashed_password = hash_password(password)
            result = conn.execute(
                text('SELECT * FROM users WHERE username = :username AND password = :password'),
                {"username": username, "password": hashed_password}
            ).fetchone()
            return result is not None
    except Exception as e:
        st.error(f"Database verification error: {str(e)}")
        return False

def create_user(username, password):
    """Create a new user in the database"""
    try:
        with engine.connect() as conn:
            hashed_password = hash_password(password)
            try:
                conn.execute(
                    text('INSERT INTO users (username, password) VALUES (:username, :password)'),
                    {"username": username, "password": hashed_password}
                )
                conn.commit()
                return True
            except Exception as e:
                st.error(f"Error inserting user: {str(e)}")
                return False
    except Exception as e:
        st.error(f"Database error during user creation: {str(e)}")
        return False

def username_exists(username):
    """Check if a username already exists"""
    try:
        with engine.connect() as conn:
            result = conn.execute(
                text('SELECT * FROM users WHERE username = :username'),
                {"username": username}
            ).fetchone()
            return result is not None
    except Exception as e:
        st.error(f"Database error checking username: {str(e)}")
        return True

def get_user_analyses(username):
    """Get all analyses for a specific user"""
    try:
        with engine.connect() as conn:
            result = conn.execute(text('''
                SELECT id, filename, timestamp, transaction_count, item_count, 
                       min_support, min_confidence, min_lift, frequent_itemset_count, rule_count
                FROM analysis_history
                WHERE username = :username
                ORDER BY timestamp DESC
            '''), {"username": username}).fetchall()
            return result
    except Exception as e:
        st.error(f"Error fetching analyses: {str(e)}")
        return []

def get_analysis_details(analysis_id, username):
    """Get details of a specific analysis"""
    try:
        with engine.connect() as conn:
            # Get analysis details
            analysis = conn.execute(text('''
                SELECT id, filename, timestamp, transaction_count, item_count, 
                       min_support, min_confidence, min_lift, frequent_itemset_count, rule_count
                FROM analysis_history
                WHERE id = :id AND username = :username
            '''), {"id": analysis_id, "username": username}).fetchone()
            
            if analysis:
                # Get itemsets
                itemsets = conn.execute(text(
                    'SELECT itemset, support FROM saved_itemsets WHERE analysis_id = :analysis_id'
                ), {"analysis_id": analysis_id}).fetchall()
                
                # Get rules
                rules = conn.execute(text('''
                    SELECT antecedents, consequents, support, confidence, lift 
                    FROM saved_rules WHERE analysis_id = :analysis_id
                '''), {"analysis_id": analysis_id}).fetchall()
                
                return analysis, itemsets, rules
            return None, None, None
    except Exception as e:
        st.error(f"Error fetching analysis details: {str(e)}")
        return None, None, None

def save_analysis(username, filename, transaction_count, item_count, min_support, min_confidence, min_lift, 
                 frequent_itemsets, rules):
    """Save analysis results to the database"""
    try:
        with engine.connect() as conn:
            # Insert analysis record
            result = conn.execute(text('''
                INSERT INTO analysis_history 
                (username, filename, transaction_count, item_count, min_support, min_confidence, min_lift, 
                 frequent_itemset_count, rule_count)
                VALUES (:username, :filename, :transaction_count, :item_count, :min_support, :min_confidence, 
                        :min_lift, :frequent_itemset_count, :rule_count)
                RETURNING id
            '''), {
                "username": username,
                "filename": filename,
                "transaction_count": transaction_count,
                "item_count": item_count,
                "min_support": min_support,
                "min_confidence": min_confidence,
                "min_lift": min_lift,
                "frequent_itemset_count": len(frequent_itemsets),
                "rule_count": len(rules)
            })
            
            analysis_id = result.fetchone()[0]
            
            # Insert itemsets
            for itemset, support in frequent_itemsets:
                conn.execute(text(
                    'INSERT INTO saved_itemsets (analysis_id, itemset, support) VALUES (:analysis_id, :itemset, :support)'
                ), {"analysis_id": analysis_id, "itemset": str(itemset), "support": support})
            
            # Insert rules
            for rule in rules:
                conn.execute(text('''
                    INSERT INTO saved_rules 
                    (analysis_id, antecedents, consequents, support, confidence, lift)
                    VALUES (:analysis_id, :antecedents, :consequents, :support, :confidence, :lift)
                '''), {
                    "analysis_id": analysis_id,
                    "antecedents": str(rule['antecedents']),
                    "consequents": str(rule['consequents']),
                    "support": rule['support'],
                    "confidence": rule['confidence'],
                    "lift": rule['lift']
                })
            
            conn.commit()
            return analysis_id
    except Exception as e:
        st.error(f"Error saving analysis: {str(e)}")
        return None

# Authentication decorator for pages
def require_auth(func):
    """Decorator to require authentication for a page"""
    def wrapper(*args, **kwargs):
        init_session_state()  # Ensure session state is initialized
        
        if not st.session_state.authenticated:
            st.warning("Please log in to access this page.")
            st.markdown("[Go to Login Page](/login)")  # Use absolute path
            st.stop()
        return func(*args, **kwargs)
    return wrapper 