import streamlit as st
import hashlib
from sqlalchemy import create_engine, text, inspect
from urllib.parse import quote_plus
from datetime import datetime
from utils.auth import (
    init_session_state, 
    verify_user, 
    init_db, 
    check_table_exists,
    engine
)

# Initialize session state
init_session_state()

# Set page config
st.set_page_config(
    page_title="Login - Market Basket Analysis",
    page_icon="🔐",
    layout="centered"
)

# Check if already logged in
if st.session_state.get('authenticated', False):
    st.success(f"You are already logged in as {st.session_state.get('username')}")
    st.markdown("Redirecting to home page...")
    st.markdown('<meta http-equiv="refresh" content="2;url=/" />', unsafe_allow_html=True)
    st.stop()

# Initialize database
if not init_db():
    st.error("Failed to initialize database. Please try again.")
    st.stop()

# Main login page
st.title("🔐 Login to Market Basket Analysis")

# Create two columns for the login form
col1, col2 = st.columns([1, 2])

with col1:
    st.image("https://cdn-icons-png.flaticon.com/512/1828/1828471.png", width=100)

with col2:
    with st.form("login_form", clear_on_submit=False):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submit_button = st.form_submit_button("Login")
        
        if submit_button:
            if not username or not password:
                st.error("Please enter both username and password.")
            else:
                try:
                    if verify_user(username, password):
                        # Set session state
                        st.session_state["authenticated"] = True
                        st.session_state["username"] = username
                        
                        st.success(f"Welcome back, {username}!")
                        st.balloons()
                        
                        # Debug info
                        st.write("Debug - Session State:")
                        st.write(f"Authenticated: {st.session_state.get('authenticated')}")
                        st.write(f"Username: {st.session_state.get('username')}")
                        
                        # Use JavaScript for immediate redirect
                        st.markdown("""
                            <script>
                                window.location.href = "/";
                            </script>
                            <meta http-equiv="refresh" content="0;url=/" />
                        """, unsafe_allow_html=True)
                        st.experimental_rerun()
                    else:
                        st.error("Invalid username or password.")
                except Exception as e:
                    st.error(f"Login error: {str(e)}")

# Add a link to the signup page
st.markdown("---")
st.markdown("Don't have an account? [Sign up here](signup)")

# Debug section
if st.checkbox("Show Database Info"):
    try:
        with engine.connect() as conn:
            # Check if table exists
            if check_table_exists('users'):
                # Get table info
                inspector = inspect(engine)
                columns = inspector.get_columns('users')
                st.write("Table Structure:")
                for col in columns:
                    st.write(f"- {col['name']}: {col['type']}")
                
                # Get user count
                result = conn.execute(text('SELECT COUNT(*) FROM users')).fetchone()
                st.write(f"\nTotal users in database: {result[0]}")
                
                # Get all users
                users = conn.execute(text('SELECT username, created_at FROM users')).fetchall()
                if users:
                    st.write("\nRegistered Users:")
                    for user in users:
                        st.write(f"Username: {user[0]}, Created: {user[1]}")
                else:
                    st.write("\nNo users found in the database.")
            else:
                st.error("Users table does not exist!")
    except Exception as e:
        st.error(f"Error fetching user data: {str(e)}")

# Add session state debug at the bottom of the page
st.markdown("---")
if st.checkbox("Show Session State Debug"):
    st.write("Current Session State:")
    st.write(dict(st.session_state)) 