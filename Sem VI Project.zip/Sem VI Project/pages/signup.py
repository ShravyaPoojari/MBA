import streamlit as st
import hashlib
from sqlalchemy import create_engine, text, inspect
from urllib.parse import quote_plus
from datetime import datetime
from utils.auth import init_session_state, create_user, username_exists, init_db, check_table_exists

# Initialize session state
init_session_state()

# Set page config
st.set_page_config(
    page_title="Sign Up - Market Basket Analysis",
    page_icon="📝",
    layout="centered"
)

# Check if already logged in
if st.session_state.authenticated:
    st.success(f"You are already logged in as {st.session_state.username}")
    st.markdown("<meta http-equiv='refresh' content='2;url=/' />", unsafe_allow_html=True)
    st.stop()

# Initialize database
if not init_db():
    st.error("Failed to initialize database. Please try again.")
    st.stop()

# Main signup page
st.title("📝 Sign Up for Market Basket Analysis")

# Create two columns for the signup form
col1, col2 = st.columns([1, 2])

with col1:
    st.image("https://cdn-icons-png.flaticon.com/512/1828/1828471.png", width=100)

with col2:
    with st.form("signup_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        confirm_password = st.text_input("Confirm Password", type="password")
        submit_button = st.form_submit_button("Sign Up")
        
        if submit_button:
            if not username or not password or not confirm_password:
                st.error("Please fill in all fields.")
            elif password != confirm_password:
                st.error("Passwords do not match.")
            elif len(password) < 6:
                st.error("Password must be at least 6 characters long.")
            elif username_exists(username):
                st.error("Username already exists. Please choose another one.")
            else:
                try:
                    if create_user(username, password):
                        st.success(f"Account created successfully! Welcome, {username}!")
                        st.balloons()
                        # Redirect to login page after a short delay
                        st.markdown("<meta http-equiv='refresh' content='2;url=/login' />", unsafe_allow_html=True)
                    else:
                        st.error("An error occurred while creating your account. Please try again.")
                except Exception as e:
                    st.error(f"Error during signup: {str(e)}")

# Add a link back to the login page
st.markdown("---")
st.markdown("Already have an account? [Login here](/login)")

# Debug section
if st.checkbox("Show Session State Debug"):
    st.write("Current Session State:")
    st.write(dict(st.session_state)) 