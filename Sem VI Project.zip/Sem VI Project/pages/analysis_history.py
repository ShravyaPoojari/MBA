import streamlit as st
import pandas as pd
from utils.auth import require_auth, get_user_analyses

# Set page config
st.set_page_config(
    page_title="Analysis History - Market Basket Analysis",
    page_icon="📊",
    layout="wide"
)

# Apply authentication requirement
@require_auth
def main():
    # Get the logged-in username
    username = st.session_state.username
    st.sidebar.write(f"Logged in as: **{username}**")
    
    st.header("Analysis History")
    
    # Get all analyses for the current user
    analyses = get_user_analyses(username)
    
    if analyses:
        # Convert to DataFrame for display
        df = pd.DataFrame([{
            "ID": a[0],
            "Filename": a[1],
            "Timestamp": a[2],
            "Transactions": a[3],
            "Items": a[4],
            "Min Support": a[5],
            "Min Confidence": a[6],
            "Min Lift": a[7],
            "Frequent Itemsets": a[8],
            "Rules": a[9]
        } for a in analyses])
        
        # Display the dataframe
        st.dataframe(df, use_container_width=True)
        
        # Add a button to view details
        if st.button("View Selected Analysis Details"):
            selected_id = st.selectbox("Select Analysis ID", options=df["ID"].tolist())
            if selected_id:
                st.switch_page(f"pages/analysis_details.py?id={selected_id}")
    else:
        st.info("You haven't performed any analyses yet. Go to the Analysis page to get started!")

# Run the main function
if __name__ == "__main__":
    main()
